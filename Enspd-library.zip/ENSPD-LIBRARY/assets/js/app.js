(function () {
'use strict';

document.addEventListener('DOMContentLoaded', function () {
    initTheme();
    initLangSwitcher();
    initNavbar();
    initUserMenu();
    initMobileMenu();
    initRealtimeSearch();
    initAdvancedFilters();
    initFileUpload();
    initFlashMessages();
    initFormValidation();
    initFeedback();
});

// ============================================================
// Theme Toggle
// ============================================================
function initTheme() {
    var toggle = document.getElementById('themeToggle');
    var html = document.documentElement;
    
    // Load saved theme
    var savedTheme = localStorage.getItem('camexamhub_theme') || 'light';
    html.setAttribute('data-theme', savedTheme);
    
    if (!toggle) return;
    toggle.addEventListener('click', function () {
        var current = html.getAttribute('data-theme');
        var next = current === 'dark' ? 'light' : 'dark';
        html.setAttribute('data-theme', next);
        localStorage.setItem('camexamhub_theme', next);
    });
}

// ============================================================
// Language Switcher
// ============================================================
function initLangSwitcher() {
    var toggle = document.getElementById('langToggle');
    var dropdown = document.getElementById('langDropdown');
    if (!toggle || !dropdown) return;
    
    toggle.addEventListener('click', function (e) {
        e.stopPropagation();
        dropdown.classList.toggle('show');
    });
        document.addEventListener('click', function (e) {
        if (!dropdown.contains(e.target) && e.target !== toggle) {
            dropdown.classList.remove('show');
        }
    });
}

// ============================================================
// Navbar Scroll
// ============================================================
function initNavbar() {
    var navbar = document.getElementById('navbar');
    if (!navbar) return;
    window.addEventListener('scroll', function () {
        if (window.scrollY > 10) navbar.classList.add('scrolled');
        else navbar.classList.remove('scrolled');
    }, { passive: true });
}

// ============================================================
// User Menu
// ============================================================
function initUserMenu() {
    var toggle = document.getElementById('userMenuToggle');
    var dropdown = document.getElementById('userDropdown');
    if (!toggle || !dropdown) return;
    toggle.addEventListener('click', function (e) {
        e.stopPropagation();
        dropdown.classList.toggle('show');
    });
    document.addEventListener('click', function (e) {
        if (!dropdown.contains(e.target) && e.target !== toggle) dropdown.classList.remove('show');
    });
    document.addEventListener('keydown', function (e) {
        if (e.key === 'Escape') dropdown.classList.remove('show');
    });
}

// ============================================================
// Mobile Menu
// ============================================================
function initMobileMenu() {
    var toggle = document.getElementById('navbarToggle');
    var menu = document.getElementById('navbarMenu');
    if (!toggle || !menu) return;
    toggle.addEventListener('click', function () {
        menu.classList.toggle('open');
        toggle.classList.toggle('active');
    });
    menu.querySelectorAll('.navbar-link').forEach(function (link) {        link.addEventListener('click', function () {
            menu.classList.remove('open');
            toggle.classList.remove('active');
        });
    });
}

// ============================================================
// Real-time Search
// ============================================================
function initRealtimeSearch() {
    var searchInput = document.getElementById('searchInput');
    var resultsContainer = document.getElementById('searchResults');
    if (!searchInput || !resultsContainer) return;
    
    var debounceTimer = null;
    
    searchInput.addEventListener('input', function () {
        clearTimeout(debounceTimer);
        var query = this.value.trim();
        
        if (query.length < 2) {
            resultsContainer.classList.remove('show');
            resultsContainer.innerHTML = '';
            return;
        }
        
        debounceTimer = setTimeout(function () {
            performSearch(query, resultsContainer);
        }, 300);
    });
    
    // Subject tag clicks
    document.querySelectorAll('.search-tag[data-subject]').forEach(function (tag) {
        tag.addEventListener('click', function (e) {
            e.preventDefault();
            searchInput.value = this.getAttribute('data-subject');
            searchInput.dispatchEvent(new Event('input'));
            searchInput.focus();
        });
    });
}

function performSearch(query, container) {
    // Get active filters
    var filters = getActiveFilters();
    var params = 'q=' + encodeURIComponent(query);
    if (filters.fileType) params += '&file_type=' + filters.fileType;
    if (filters.dateRange) params += '&date_range=' + filters.dateRange;
    if (filters.downloadMin) params += '&download_min=' + filters.downloadMin;    if (filters.examLevel) params += '&exam_level=' + filters.examLevel;
    if (filters.difficulty) params += '&difficulty=' + filters.difficulty;
    
    container.classList.add('show');
    container.innerHTML = '<div class="text-center mt-8"><div class="loading-spinner"></div><p class="mt-4" style="color:var(--text-secondary)">Searching...</p></div>';
    
    var xhr = new XMLHttpRequest();
    xhr.open('GET', 'api/search.php?' + params, true);
    xhr.setRequestHeader('X-Requested-With', 'XMLHttpRequest');
    xhr.onload = function () {
        if (xhr.status === 200) {
            try {
                var data = JSON.parse(xhr.responseText);
                displaySearchResults(data, container);
            } catch (err) {
                container.innerHTML = '<div class="alert alert-error">Error parsing results.</div>';
            }
        }
    };
    xhr.send();
}

function getActiveFilters() {
    var filters = {};
    var fileTypeEl = document.getElementById('filterFileType');
    var dateRangeEl = document.getElementById('filterDateRange');
    var downloadEl = document.getElementById('filterDownloads');
    var levelEl = document.getElementById('filterExamLevel');
    var difficultyEl = document.getElementById('filterDifficulty');
    
    if (fileTypeEl && fileTypeEl.value) filters.fileType = fileTypeEl.value;
    if (dateRangeEl && dateRangeEl.value) filters.dateRange = dateRangeEl.value;
    if (downloadEl && downloadEl.value) filters.downloadMin = downloadEl.value;
    if (levelEl && levelEl.value) filters.examLevel = levelEl.value;
    if (difficultyEl && difficultyEl.value) filters.difficulty = difficultyEl.value;
    
    return filters;
}

function displaySearchResults(data, container) {
    if (!data.success || !data.papers || data.papers.length === 0) {
        container.innerHTML = '<div class="empty-state"><div class="empty-state-icon">🔍</div><h2>No papers found</h2><p>Try different keywords or browse our subjects.</p></div>';
        return;
    }
    
    var html = '<div class="search-results-header">' + data.papers.length + ' paper' + (data.papers.length !== 1 ? 's' : '') + ' found</div>';
    html += '<div class="search-results-list">';
    data.papers.forEach(function (paper) {
        html += '<div class="search-result-item" onclick="window.location.href=\'pages/paper.php?id=' + paper.id + '\'">';
        html += '<div class="search-result-info">';        html += '<h4>' + escapeHtml(paper.title) + '</h4>';
        html += '<p>' + escapeHtml(paper.authors || 'Unknown authors') + '</p>';
        html += '</div>';
        html += '<div class="search-result-meta">';
        html += '<span>👁 ' + (paper.view_count || 0) + '</span>';
        html += '<span>⬇ ' + (paper.download_count || 0) + '</span>';
        html += '</div>';
        html += '</div>';
    });
    html += '</div>';
    container.innerHTML = html;
}

// ============================================================
// Advanced Filters Toggle
// ============================================================
function initAdvancedFilters() {
    var toggleBtn = document.getElementById('filtersToggle');
    var filtersPanel = document.getElementById('advancedFilters');
    if (!toggleBtn || !filtersPanel) return;
    
    toggleBtn.addEventListener('click', function () {
        filtersPanel.classList.toggle('show');
        var isShown = filtersPanel.classList.contains('show');
        this.innerHTML = isShown 
            ? '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M18 15l-6-6-6 6"/></svg> Hide Filters'
            : '<svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><path d="M6 9l6 6 6-6"/></svg> Advanced Filters';
    });
    
    // Apply filters button
    var applyBtn = document.getElementById('applyFilters');
    if (applyBtn) {
        applyBtn.addEventListener('click', function () {
            var searchInput = document.getElementById('searchInput');
            if (searchInput && searchInput.value.trim()) {
                searchInput.dispatchEvent(new Event('input'));
            }
        });
    }
}

// ============================================================
// File Upload
// ============================================================
function initFileUpload() {
    var dropzone = document.getElementById('uploadDropzone');
    var fileInput = document.getElementById('fileInput');
    var fileInfo = document.getElementById('fileInfo');
    if (!dropzone || !fileInput) return;
        dropzone.addEventListener('click', function () { fileInput.click(); });
    fileInput.addEventListener('change', function () {
        if (this.files && this.files[0]) handleFileSelect(this.files[0]);
    });
    
    ['dragenter', 'dragover'].forEach(function (eventName) {
        dropzone.addEventListener(eventName, function (e) {
            e.preventDefault(); e.stopPropagation();
            dropzone.classList.add('dragover');
        });
    });
    ['dragleave', 'drop'].forEach(function (eventName) {
        dropzone.addEventListener(eventName, function (e) {
            e.preventDefault(); e.stopPropagation();
            dropzone.classList.remove('dragover');
        });
    });
    dropzone.addEventListener('drop', function (e) {
        var files = e.dataTransfer.files;
        if (files && files[0]) handleFileSelect(files[0]);
    });
    
    function handleFileSelect(file) {
        var allowedExts = ['pdf', 'docx', 'txt', 'rtf'];
        var ext = file.name.split('.').pop().toLowerCase();
        if (allowedExts.indexOf(ext) === -1) {
            alert('File type not allowed. Please upload: ' + allowedExts.join(', '));
            return;
        }
        var maxSize = 50 * 1024 * 1024;
        if (file.size > maxSize) { alert('File size exceeds 50MB limit.'); return; }
        if (fileInfo) {
            fileInfo.querySelector('.file-name-text').textContent = file.name;
            fileInfo.querySelector('.file-size-text').textContent = formatFileSize(file.size);
            fileInfo.classList.add('show');
        }
    }
}

// ============================================================
// Flash Messages
// ============================================================
function initFlashMessages() {
    document.querySelectorAll('.alert').forEach(function (alert) {
        setTimeout(function () {
            alert.style.opacity = '0';
            alert.style.transform = 'translateY(-10px)';
            setTimeout(function () { alert.remove(); }, 300);
        }, 5000);
    });}

// ============================================================
// Form Validation
// ============================================================
function initFormValidation() {
    document.querySelectorAll('form.needs-validation').forEach(function (form) {
        form.addEventListener('submit', function (e) {
            var isValid = true;
            form.querySelectorAll('[required]').forEach(function (field) {
                if (!field.value.trim()) {
                    field.style.borderColor = 'var(--danger)';
                    isValid = false;
                } else {
                    field.style.borderColor = '';
                }
            });
            var password = form.querySelector('input[name="password"]');
            var confirm = form.querySelector('input[name="confirm_password"]');
            if (password && confirm && password.value !== confirm.value) {
                confirm.style.borderColor = 'var(--danger)';
                isValid = false;
            }
            if (!isValid) e.preventDefault();
        });
    });
}

// ============================================================
// Feedback
// ============================================================
function initFeedback() {
    document.querySelectorAll('.feedback-btn').forEach(function (btn) {
        btn.addEventListener('click', function () {
            var paperId = this.getAttribute('data-paper-id');
            var isHelpful = this.getAttribute('data-helpful') === '1';
            var xhr = new XMLHttpRequest();
            xhr.open('POST', 'api/feedback.php', true);
            xhr.setRequestHeader('Content-Type', 'application/x-www-form-urlencoded');
            xhr.onload = function () {
                if (xhr.status === 200) {
                    document.querySelectorAll('.feedback-btn[data-paper-id="' + paperId + '"]').forEach(function (b) {
                        b.classList.remove('active-helpful', 'active-not-helpful');
                    });
                    this.classList.add(isHelpful ? 'active-helpful' : 'active-not-helpful');
                    var thanks = document.getElementById('feedbackThanks');
                    if (thanks) thanks.style.display = 'block';
                }
            }.bind(this);
            xhr.send('paper_id=' + paperId + '&is_helpful=' + (isHelpful ? 1 : 0));        });
    });
}

// ============================================================
// Utilities
// ============================================================
function escapeHtml(text) {
    if (!text) return '';
    var div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

function formatFileSize(bytes) {
    if (bytes === 0) return '0 B';
    var units = ['B', 'KB', 'MB', 'GB'];
    var i = Math.floor(Math.log(bytes) / Math.log(1024));
    return (bytes / Math.pow(1024, i)).toFixed(1) + ' ' + units[i];
}

})();

function confirmDownload() { return true; }
