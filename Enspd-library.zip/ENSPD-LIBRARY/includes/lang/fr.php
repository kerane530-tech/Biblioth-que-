<?php
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

return [
    // Navigation
    'home' => 'Accueil',
    'browse' => 'Formations',
    'upload' => 'Télécharger',
    'login' => 'Connexion',
    'register' => "S'inscrire",
    'logout' => 'Déconnexion',
    'profile' => 'Mon Profil',
    
    // Search
    'search_placeholder' => 'Rechercher par titre, auteur, mot-clé ou sujet...',
    'search_btn' => 'Rechercher',
    
    // Home Page
    'discover_title' => 'Découvrir les Articles de Recherche',
    'discover_subtitle' => 'Recherchez parmi des milliers d\'articles académiques dans toutes les disciplines. Trouvez, prévisualisez et téléchargez des recherches qui comptent pour vous.',
    
    // Stats
    'research_papers' => 'Articles de Recherche',
    'subjects' => 'Sujets',
    'researchers' => 'Chercheurs',
    'downloads' => 'Téléchargements',
    
    // Browse
    'browse_by_subject' => 'Parcourir par Sujet',
    'explore_research' => 'Explorez les articles de recherche organisés par discipline académique',
    'all_subjects' => 'Tous les Sujets',
    'sort_by' => 'Trier Par',
    'apply_filters' => 'Appliquer les Filtres',
    'newest_first' => 'Plus Récent',
    'most_downloaded' => 'Plus Téléchargés',
    'most_viewed' => 'Plus Vus',
    'title_az' => 'Titre A-Z',
    
    // Paper
    'preview' => 'Aperçu',
    'download' => 'Télécharger',
    'views' => 'Vues',
    'authors' => 'Auteurs',
    'year' => 'Année',
    'published_in' => 'Publié dans',
    'abstract' => 'Résumé',
    'keywords' => 'Mots-clés',    'document_info' => 'Informations sur le Document',
    'file_name' => 'Nom du Fichier',
    'file_type' => 'Type de Fichier',
    'file_size' => 'Taille du Fichier',
    'related_papers' => 'Articles Connexes',
    
    // Upload
    'upload_paper' => 'Télécharger un Article',
    'paper_title' => 'Titre de l\'Article',
    'subject_category' => 'Catégorie de Sujet',
    'publication_year' => 'Année de Publication',
    'journal_conference' => 'Journal / Conférence',
    'doi' => 'DOI',
    'select_subject' => '— Sélectionner un sujet —',
    'drag_drop' => 'Glissez-déposez votre fichier ici',
    'or_click_browse' => 'ou cliquez pour parcourir',
    'max_50mb' => 'Max 50Mo',
    
    // Profile
    'member_since' => 'Membre depuis',
    'papers_uploaded' => 'Articles Téléchargés',
    'total_views' => 'Total des Vues',
    'total_downloads' => 'Total des Téléchargements',
    'my_uploaded_papers' => 'Mes Articles Téléchargés',
    'recent_downloads' => 'Téléchargements Récents',
    'no_papers_uploaded' => 'Aucun article téléchargé',
    'start_sharing' => 'Commencez à partager vos recherches avec la communauté',
    'upload_first_paper' => 'Téléchargez votre premier article',
    
    // Auth
    'welcome_back' => 'Connexion',
    'signin_account' => 'Connectez-vous à votre compte ENSPD-LIBRARY',
    'email_address' => 'Adresse Email',
    'password' => 'Mot de Passe',
    'signin' => 'Se Connecter',
    'dont_have_account' => "Vous n'avez pas de compte ?",
    'create_one' => 'Créez-en un',
    'create_account' => 'Créer un Compte',
    'join_community' => 'Rejoignez la communauté ENSPD-LIBRARY',
    'username' => "Nom d'Utilisateur",
    'full_name' => 'Nom Complet',
    'confirm_password' => 'Confirmer le Mot de Passe',
    'already_have_account' => 'Vous avez déjà un compte ?',
    'sign_in' => 'Se connecter',
    
    // Common
    'required' => '*',
    'submit' => 'Soumettre',
    'cancel' => 'Annuler',
    'save' => 'Enregistrer',    'delete' => 'Supprimer',
    'edit' => 'Modifier',
    'view' => 'Voir',
    'close' => 'Fermer',
    'loading' => 'Chargement...',
    'no_results' => 'Aucun résultat trouvé',
    'error' => 'Erreur',
    'success' => 'Succès',
];