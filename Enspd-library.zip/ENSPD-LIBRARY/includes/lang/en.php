<?php
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

return [
    // Navigation
    'home' => 'Home',
    'browse' => 'Browse',
    'upload' => 'Upload',
    'login' => 'Log In',
    'register' => 'Sign Up',
    'logout' => 'Logout',
    'profile' => 'My Profile',
    
    // Search
    'search_placeholder' => 'Search by title, author, keyword, or subject...',
    'search_btn' => 'Search',
    
    // Home Page
    'discover_title' => 'Discover Research Papers',
    'discover_subtitle' => 'Search through thousands of academic papers across all disciplines. Find, preview, and download research that matters to you.',
    
    // Stats
    'research_papers' => 'Research Papers',
    'subjects' => 'Subjects',
    'researchers' => 'Researchers',
    'downloads' => 'Downloads',
    
    // Browse
    'browse_by_subject' => 'Browse by Subject',
    'explore_research' => 'Explore research papers organized by academic discipline',
    'all_subjects' => 'All Subjects',
    'sort_by' => 'Sort By',
    'apply_filters' => 'Apply Filters',
    'newest_first' => 'Newest First',
    'most_downloaded' => 'Most Downloaded',
    'most_viewed' => 'Most Viewed',
    'title_az' => 'Title A-Z',
    
    // Paper
    'preview' => 'Preview',
    'download' => 'Download',
    'views' => 'Views',
    'authors' => 'Authors',
    'year' => 'Year',
    'published_in' => 'Published in',
    'abstract' => 'Abstract',
    'keywords' => 'Keywords',    'document_info' => 'Document Information',
    'file_name' => 'File Name',
    'file_type' => 'File Type',
    'file_size' => 'File Size',
    'related_papers' => 'Related Papers',
    
    // Upload
    'upload_paper' => 'Upload Research Paper',
    'paper_title' => 'Paper Title',
    'subject_category' => 'Subject Category',
    'publication_year' => 'Publication Year',
    'journal_conference' => 'Journal / Conference',
    'doi' => 'DOI',
    'select_subject' => '— Select a subject —',
    'drag_drop' => 'Drag & drop your file here',
    'or_click_browse' => 'or click to browse',
    'max_50mb' => 'Max 50MB',
    
    // Profile
    'member_since' => 'Member since',
    'papers_uploaded' => 'Papers Uploaded',
    'total_views' => 'Total Views',
    'total_downloads' => 'Total Downloads',
    'my_uploaded_papers' => 'My Uploaded Papers',
    'recent_downloads' => 'Recent Downloads',
    'no_papers_uploaded' => 'No papers uploaded yet',
    'start_sharing' => 'Start sharing your research with the community',
    'upload_first_paper' => 'Upload Your First Paper',
    
    // Auth
    'welcome_back' => 'Welcome Back',
    'signin_account' => 'Sign in to your ENSPD-LIBRARY account',
    'email_address' => 'Email Address',
    'password' => 'Password',
    'signin' => 'Sign In',
    'dont_have_account' => "Don't have an account?",
    'create_one' => 'Create one',
    'create_account' => 'Create Account',
    'join_community' => 'Join the ENSPD-LIBRARY community',
    'username' => 'Username',
    'full_name' => 'Full Name',
    'confirm_password' => 'Confirm Password',
    'already_have_account' => 'Already have an account?',
    'sign_in' => 'Sign in',
    
    // Common
    'required' => '*',
    'submit' => 'Submit',
    'cancel' => 'Cancel',
    'save' => 'Save',    'delete' => 'Delete',
    'edit' => 'Edit',
    'view' => 'View',
    'close' => 'Close',
    'loading' => 'Loading...',
    'no_results' => 'No results found',
    'error' => 'Error',
    'success' => 'Success',
];