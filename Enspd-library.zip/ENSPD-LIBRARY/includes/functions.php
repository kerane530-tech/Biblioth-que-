<?php
/**
* ============================================================
* Utility Functions
* ============================================================
*
* Collection of helper functions used throughout the application:
* - Input sanitization and escaping
* - File handling and validation
* - Pagination helpers
* - Search query building
* - Flash messages for user feedback
* - URL helpers
* ============================================================
*/

// Prevent direct access
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

/**
* Sanitize user input for safe HTML output
*
* Wraps PHP's htmlspecialchars with sensible defaults
* to prevent XSS (Cross-Site Scripting) attacks.
*
* @param string $input Raw user input
* @return string       Sanitized output safe for HTML
*/
function sanitize(string $input): string {
    return htmlspecialchars(trim($input), ENT_QUOTES, 'UTF-8');
}

/**
* Sanitize a string for use in a URL slug
*
* Converts text to lowercase, replaces spaces and special
* characters with hyphens, and removes consecutive/repeated hyphens.
*
* @param string $text Input text
* @return string      URL-friendly slug
*/
function slugify(string $text): string {
    $text = strtolower(trim($text));
    $text = preg_replace('/[^a-z0-9-]/', '-', $text);
    $text = preg_replace('/-+/', '-', $text);
    return trim($text, '-');
}
/**
* Set a flash message to display after redirect
*
* Flash messages persist for exactly one page load, making them
* ideal for success/error notifications after form submissions.
*
* @param string $type    Message type: 'success', 'error', 'warning', 'info'
* @param string $message Message text to display
*/
function setFlash(string $type, string $message): void {
    $_SESSION['flash'] = [
        'type'    => $type,
        'message' => $message,
    ];
}

/**
* Retrieve and clear the current flash message
*
* Returns the message on first call, then removes it from
* the session so it doesn't display again.
*
* @return array|null Flash message array with 'type' and 'message', or null
*/
function getFlash(): ?array {
    if (isset($_SESSION['flash'])) {
        $flash = $_SESSION['flash'];
        unset($_SESSION['flash']);
        return $flash;
    }
    return null;
}

/**
* Render flash message HTML if a message exists
*
* Outputs a styled alert box with appropriate icon and color
* based on the message type.
*/
function renderFlash(): void {
    $flash = getFlash();
    if (!$flash) return;
    
    // Map message types to CSS classes and icons
    $config = [
        'success' => ['class' => 'alert-success', 'icon' => '✓'],
        'error'   => ['class' => 'alert-error',   'icon' => '✕'],
        'warning' => ['class' => 'alert-warning', 'icon' => '⚠'],
        'info'    => ['class' => 'alert-info',    'icon' => 'ℹ'],    ];
    
    $cfg = $config[$flash['type']] ?? $config['info'];
    
    echo '<div class="alert ' . $cfg['class'] . '" role="alert">';
    echo '<span class="alert-icon">' . $cfg['icon'] . '</span>';
    echo '<span class="alert-text">' . sanitize($flash['message']) . '</span>';
    echo '<button class="alert-close" onclick="this.parentElement.remove()" aria-label="Close">&times;</button>';
    echo '</div>';
}

/**
* Handle file upload with validation
*
* Validates file type, size, and name before moving to the
* uploads directory. Generates a unique filename to prevent
* collisions and overwrites.
*
* @param array  $file        $_FILES['field'] array
* @param string $destination Target directory path
* @param array  $allowedExts Array of allowed extensions (optional, uses default)
* @return array              ['success' => bool, 'path' => string, 'name' => string, 'error' => string]
*/
function handleUpload(array $file, string $destination, array $allowedExts = []): array {
    // Use default allowed extensions if none specified
    if (empty($allowedExts)) {
        $allowedExts = ALLOWED_EXTENSIONS;
    }
    
    // Check for upload errors
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $errors = [
            UPLOAD_ERR_INI_SIZE   => 'File exceeds server upload limit.',
            UPLOAD_ERR_FORM_SIZE  => 'File exceeds form upload limit.',
            UPLOAD_ERR_PARTIAL    => 'File was only partially uploaded.',
            UPLOAD_ERR_NO_FILE    => 'No file was uploaded.',
            UPLOAD_ERR_NO_TMP_DIR => 'Server missing temporary upload folder.',
            UPLOAD_ERR_CANT_WRITE => 'Failed to write file to disk.',
        ];
        $msg = $errors[$file['error']] ?? 'Unknown upload error occurred.';
        return ['success' => false, 'path' => '', 'name' => '', 'error' => $msg];
    }
    
    // Validate file size
    if ($file['size'] > MAX_FILE_SIZE) {
        return [
            'success' => false, 'path' => '', 'name' => '',
            'error' => 'File size exceeds the maximum limit of ' . formatFileSize(MAX_FILE_SIZE) . '.'
        ];
    }    
    if ($file['size'] === 0) {
        return ['success' => false, 'path' => '', 'name' => '', 'error' => 'Uploaded file is empty.'];
    }
    
    // Validate file extension
    $originalName = basename($file['name']);
    $extension = strtolower(pathinfo($originalName, PATHINFO_EXTENSION));
    
    if (!in_array($extension, $allowedExts, true)) {
        return [
            'success' => false, 'path' => '', 'name' => '',
            'error' => 'File type not allowed. Accepted: ' . implode(', ', $allowedExts) . '.'
        ];
    }
    
    // Validate MIME type using file info (more reliable than extension alone)
    $finfo = new finfo(FILEINFO_MIME_TYPE);
    $mimeType = $finfo->file($file['tmp_name']);
    $allowedMimes = [
        'pdf'  => 'application/pdf',
        'doc'  => 'application/msword',
        'docx' => 'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
        'txt'  => 'text/plain',
        'rtf'  => 'application/rtf',
    ];
    
    if (isset($allowedMimes[$extension]) && $mimeType !== $allowedMimes[$extension]) {
        // Additional check: some systems report different MIME types
        // Allow it if extension matches but be aware of potential risk
        error_log("MIME mismatch for {$originalName}: expected {$allowedMimes[$extension]}, got {$mimeType}");
    }
    
    // Generate unique filename to prevent collisions
    $uniqueName = date('Y-m-d_H-i-s') . '_' . bin2hex(random_bytes(8)) . '.' . $extension;
    
    // Create destination directory if it doesn't exist
    if (!is_dir($destination)) {
        mkdir($destination, 0755, true);
    }
    
    // Build the full destination path
    $targetPath = rtrim($destination, '/') . '/' . $uniqueName;
    
    // Move uploaded file to destination
    if (!move_uploaded_file($file['tmp_name'], $targetPath)) {
        return ['success' => false, 'path' => '', 'name' => '', 'error' => 'Failed to save uploaded file.'];
    }
    
    return [        'success' => true,
        'path'    => $targetPath,
        'name'    => $originalName,
        'saved'   => $uniqueName,
        'error'   => '',
    ];
}

/**
* Format file size in human-readable units
*
* Converts bytes to KB, MB, or GB as appropriate.
*
* @param int    $bytes    File size in bytes
* @param int    $decimals Number of decimal places (default: 1)
* @return string          Formatted size string (e.g., "2.5 MB")
*/
function formatFileSize(int $bytes, int $decimals = 1): string {
    if ($bytes === 0) return '0 B';
    $units = ['B', 'KB', 'MB', 'GB', 'TB'];
    $i = (int)floor(log($bytes, 1024));
    $i = min($i, count($units) - 1);
    return round($bytes / (1024 ** $i), $decimals) . ' ' . $units[$i];
}

/**
* Generate pagination HTML and data
*
* Calculates page offsets and generates navigation links
* for paginated result sets.
*
* @param int    $totalItems Total number of items across all pages
* @param int    $perPage    Items per page
* @param int    $currentPage Current page number (1-based)
* @param string $baseUrl    Base URL for page links
* @param array   $params    Additional URL parameters to preserve
* @return array             ['html' => string, 'totalPages' => int, 'offset' => int]
*/
function paginate(int $totalItems, int $perPage, int $currentPage, string $baseUrl = '', array $params = []): array {
    $totalPages = max(1, (int)ceil($totalItems / $perPage));
    $currentPage = max(1, min($currentPage, $totalPages));
    $offset = ($currentPage - 1) * $perPage;
    
    // Don't generate HTML if only one page
    if ($totalPages <= 1) {
        return ['html' => '', 'totalPages' => $totalPages, 'offset' => $offset];
    }
    
    // Build base query string from params
    $queryString = '';    if (!empty($params)) {
        $queryString = http_build_query($params);
    }
    
    $sep = $queryString ? '&' : '?';
    $baseUrlWithParams = $baseUrl . ($queryString ? '?' . $queryString : '');
    $sep = '&';
    
    $html = '<nav class="pagination" aria-label="Page navigation">';
    $html .= '<ul class="pagination-list">';
    
    // Previous button
    if ($currentPage > 1) {
        $html .= '<li><a href="' . $baseUrlWithParams . $sep . 'page=' . ($currentPage - 1) . '" class="pagination-link">&laquo; Prev</a></li>';
    } else {
        $html .= '<li><span class="pagination-link disabled">&laquo; Prev</span></li>';
    }
    
    // Page numbers (show max 5 pages around current)
    $start = max(1, $currentPage - 2);
    $end = min($totalPages, $currentPage + 2);
    
    if ($start > 1) {
        $html .= '<li><a href="' . $baseUrlWithParams . $sep . 'page=1" class="pagination-link">1</a></li>';
        if ($start > 2) $html .= '<li><span class="pagination-ellipsis">…</span></li>';
    }
    
    for ($i = $start; $i <= $end; $i++) {
        if ($i == $currentPage) {
            $html .= '<li><span class="pagination-link active">' . $i . '</span></li>';
        } else {
            $html .= '<li><a href="' . $baseUrlWithParams . $sep . 'page=' . $i . '" class="pagination-link">' . $i . '</a></li>';
        }
    }
    
    if ($end < $totalPages) {
        if ($end < $totalPages - 1) $html .= '<li><span class="pagination-ellipsis">…</span></li>';
        $html .= '<li><a href="' . $baseUrlWithParams . $sep . 'page=' . $totalPages . '" class="pagination-link">' . $totalPages . '</a></li>';
    }
    
    // Next button
    if ($currentPage < $totalPages) {
        $html .= '<li><a href="' . $baseUrlWithParams . $sep . 'page=' . ($currentPage + 1) . '" class="pagination-link">Next &raquo;</a></li>';
    } else {
        $html .= '<li><span class="pagination-link disabled">Next &raquo;</span></li>';
    }
    
    $html .= '</ul></nav>';
    
    return ['html' => $html, 'totalPages' => $totalPages, 'offset' => $offset];}

/**
* Build a safe search query with LIKE patterns
*
* Splits search terms and creates individual LIKE conditions
* connected by AND, so all terms must match.
*
* @param string $searchInput Raw search string from user
* @return array              ['conditions' => string, 'params' => array]
*/
function buildSearchQuery(string $searchInput): array {
    $conditions = [];
    $params = [];
    
    // Split input into individual terms
    $terms = array_filter(array_map('trim', explode(' ', $searchInput)));
    
    foreach ($terms as $term) {
        // Sanitize each search term
        $safeTerm = '%' . preg_replace('/[^a-zA-Z0-9]/', '', $term) . '%';
        $conditions[] = '(p.title LIKE ? OR p.authors LIKE ? OR p.abstract LIKE ? OR p.keywords LIKE ?)';
        $params[] = $safeTerm;
        $params[] = $safeTerm;
        $params[] = $safeTerm;
        $params[] = $safeTerm;
    }
    
    return [
        'conditions' => $conditions ? implode(' AND ', $conditions) : '1=1',
        'params'     => $params,
    ];
}

/**
* Get all active subjects from the database
*
* Returns subjects ordered by paper count (most papers first).
*
* @return array List of subject records
*/
function getSubjects(): array {
    return dbFetchAll(
        "SELECT id, name, slug, description, icon, paper_count
         FROM subjects ORDER BY paper_count DESC, name ASC"
    );
}

/**
* Get a single subject by ID or slug*
* @param int|string $identifier Subject ID (int) or slug (string)
* @return array|null            Subject record or null
*/
function getSubject($identifier): ?array {
    if (is_numeric($identifier)) {
        return dbFetchOne("SELECT * FROM subjects WHERE id = ?", [(int)$identifier]);
    }
    return dbFetchOne("SELECT * FROM subjects WHERE slug = ?", [$identifier]);
}

/**
* Get a single paper by ID with full details
*
* Also increments the view count.
*
* @param int $paperId Paper ID
* @return array|null  Paper record with subject and uploader info
*/
function getPaper(int $paperId): ?array {
    // Increment view count
    dbQuery("UPDATE papers SET view_count = view_count + 1 WHERE id = ?", [$paperId]);
    
    // Fetch paper with joins for subject and uploader info
    return dbFetchOne(
        "SELECT p.*, s.name AS subject_name, s.slug AS subject_slug, s.icon AS subject_icon,
         u.username AS uploader_name, u.full_name AS uploader_full_name
         FROM papers p
         JOIN subjects s ON p.subject_id = s.id
         JOIN users u ON p.uploaded_by = u.id
         WHERE p.id = ? AND p.status = 'approved'",
        [$paperId]
    );
}

/**
* Record a paper download
*
* Increments the download counter and creates a download record.
*
* @param int      $paperId Paper being downloaded
* @param int|null $userId  User ID (null for guests)
*/
function recordDownload(int $paperId, ?int $userId = null): void {
    // Increment paper's download counter
    dbQuery("UPDATE papers SET download_count = download_count + 1 WHERE id = ?", [$paperId]);
    
    // Create download log entry
    dbQuery(
        "INSERT INTO downloads (user_id, paper_id, ip_address, user_agent)         VALUES (?, ?, ?, ?)",
        [
            $userId,
            $paperId,
            $_SERVER['REMOTE_ADDR'] ?? null,
            substr($_SERVER['HTTP_USER_AGENT'] ?? '', 0, 500),
        ]
    );
}

/**
* Record feedback on a paper
*
* @param int      $paperId  Paper ID
* @param bool     $isHelpful Whether feedback is helpful
* @param int|null $userId   User ID
* @return bool              Success status
*/
function recordFeedback(int $paperId, bool $isHelpful, ?int $userId = null): bool {
    try {
        dbQuery(
            "INSERT INTO paper_feedback (paper_id, user_id, is_helpful, ip_address)
             VALUES (?, ?, ?, ?)",
            [$paperId, $userId, $isHelpful ? 1 : 0, $_SERVER['REMOTE_ADDR'] ?? null]
        );
        
        $column = $isHelpful ? 'helpful_count' : 'not_helpful_count';
        dbQuery("UPDATE papers SET {$column} = {$column} + 1 WHERE id = ?", [$paperId]);
        
        return true;
    } catch (Exception $e) {
        return false;
    }
}

/**
* Truncate text to a specified length with ellipsis
*
* @param string $text   Input text
* @param int    $length Maximum character length
* @return string        Truncated text with "..." if needed
*/
function truncate(string $text, int $length = 200): string {
    if (strlen($text) <= $length) return $text;
    return substr($text, 0, $length) . '...';
}

/**
* Format a date for display
** @param string $date  Date string from database
* @param string $format Output format (default: "M d, Y")
* @return string       Formatted date
*/
function formatDate(string $date, string $format = 'M d, Y'): string {
    return date($format, strtotime($date));
}

/**
* Get the relative time string (e.g., "2 hours ago")
*
* @param string $datetime Database datetime string
* @return string          Human-readable relative time
*/
function timeAgo(string $datetime): string {
    $time = strtotime($datetime);
    $diff = time() - $time;
    
    if ($diff < 60)       return 'just now';
    if ($diff < 3600)     return floor($diff / 60) . ' min ago';
    if ($diff < 86400)    return floor($diff / 3600) . ' hours ago';
    if ($diff < 604800)   return floor($diff / 86400) . ' days ago';
    if ($diff < 2592000)  return floor($diff / 604800) . ' weeks ago';
    return formatDate($datetime);
}

/**
* Get application setting by key (with caching)
*
* @param string $key     Setting key name
* @param mixed  $default Default value if not found
* @return mixed          Setting value or default
*/
function getSetting(string $key, $default = '') {
    static $settings = null;
    
    if ($settings === null) {
        try {
            // Try settings table first (new schema)
            $rows = dbFetchAll("SELECT setting_key, setting_value FROM settings");
            $settings = array_column($rows, 'setting_value', 'setting_key');
        } catch (Exception $e) {
            try {
                // Fallback to app_settings table (old schema)
                $rows = dbFetchAll("SELECT key_name, key_value FROM app_settings");
                $settings = array_column($rows, 'key_value', 'key_name');
            } catch (Exception $e2) {
                $settings = [];
            }
        }    }
    
    return $settings[$key] ?? $default;
}

/**
* Update or create a setting
*
* @param string $key   Setting key
* @param string $value Setting value
*/
function updateSetting(string $key, string $value): void {
    try {
        dbQuery(
            "INSERT INTO settings (setting_key, setting_value) VALUES (?, ?)
             ON DUPLICATE KEY UPDATE setting_value = ?",
            [$key, $value, $value]
        );
    } catch (Exception $e) {
        try {
            dbQuery(
                "INSERT INTO app_settings (key_name, key_value) VALUES (?, ?)
                 ON DUPLICATE KEY UPDATE key_value = ?",
                [$key, $value, $value]
            );
        } catch (Exception $e2) {
            error_log("Failed to update setting: " . $e2->getMessage());
        }
    }
}

/**
* Get the site name from settings
*
* @return string Site name
*/
function getSiteName(): string {
    return getSetting('site_name', APP_NAME);
}

/**
* Get the site logo URL
*
* @return string Logo URL
*/
function getSiteLogo(): string {
    $logo = getSetting('logo_path');
    return $logo ? APP_URL . '/' . $logo : APP_URL . '/assets/images/default-logo.svg';
}
/**
* Get the base application URL
*
* @return string Base URL of the application
*/
function getBaseUrl(): string {
    return APP_URL;
}