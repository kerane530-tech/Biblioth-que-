<?php
/**
 * ============================================================
 * Logout Script (logout.php)
 * ============================================================
 * 
 * Processes user logout by:
 * 1. Clearing all session data
 * 2. Destroying the session
 * 3. Deleting the session cookie
 * 4. Redirecting to the homepage
 * 
 * This is a processor script — it has no visible output.
 * ============================================================
 */

// Initialize the application
require_once  'C:\xampp\htdocs\CAMEXAMHUB\includes\bootstrap.php';

// Perform the logout
logoutUser();

// logoutUser() calls exit() internally, so code below won't execute
