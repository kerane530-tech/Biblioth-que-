<?php
define('APP_RUNNING', true);

// Fixed relative paths for portability
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/auth.php';
require_once __DIR__ . '/functions.php';
require_once __DIR__ . '/lang.php';

initSession();

// Language Switcher Logic
if (isset($_GET['lang']) && in_array($_GET['lang'], ['en', 'fr'])) {
    $_SESSION['lang'] = $_GET['lang'];
    if (isLoggedIn()) {
        dbQuery("UPDATE users SET preferred_lang = ? WHERE id = ?", [$_SESSION['lang'], $_SESSION['user_id']]);
    }
    $referer = $_SERVER['HTTP_REFERER'] ?? APP_URL;
    header("Location: " . strtok($referer, '?') . '?' . http_build_query(array_merge($_GET, ['lang' => null])));
    exit;
}

// Load User Language Preference
global $translations;
$lang = $_SESSION['lang'] ?? 'en';
if (isLoggedIn()) {
    $user = getCurrentUser();
    if ($user && !empty($user['preferred_lang'])) {
        $lang = $user['preferred_lang'];
        $_SESSION['lang'] = $lang;
    }
}
$translations = loadLanguage($lang);