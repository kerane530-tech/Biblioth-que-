<?php
$pageTitle = $pageTitle ?? getSiteName();
$pageDesc  = $pageDesc ?? 'Discover academic research papers.';
$activePage = $activePage ?? 'home';
$currentUser = getCurrentUser();
?>
<!DOCTYPE html>
<html lang="<?= $_SESSION['lang'] ?? 'en' ?>">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?= sanitize($pageTitle) ?> — ENSPD-LIBRARY</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <!-- Font Awesome 6 -->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="<?= APP_URL ?>/assets/css/style.css">
</head>
<body>
<header class="navbar" id="navbar">
    <div class="container navbar-inner">
        <a href="<?= APP_URL ?>/index.php" class="navbar-brand">
            <img
src="<?= APP_URL ?>/assets/images/images.png"
alt="ENSPD"
style="height:60px"
>
            <i class="fa-solid fa-book-open-reader brand-icon" style="display:none;"></i>
            <span class="brand-text">ENSPD-LIBRARY</span>
        </a>
        
        <nav class="navbar-menu" id="navbarMenu">
            <a href="<?= APP_URL ?>/index.php" class="navbar-link <?= $activePage === 'home' ? 'active' : '' ?>">
                <i class="fa-solid fa-house"></i> <?= t('home') ?>
            </a>
            <a href="<?= APP_URL ?>/pages/browse.php" class="navbar-link <?= $activePage === 'browse' ? 'active' : '' ?>">
                <i class="fa-solid fa-magnifying-glass"></i> <?= t('browse') ?>
            </a>
            <?php if ($currentUser): ?>
                <a href="<?= APP_URL ?>/pages/upload.php" class="navbar-link <?= $activePage === 'upload' ? 'active' : '' ?>">
                    <i class="fa-solid fa-cloud-arrow-up"></i> <?= t('upload') ?>
                </a>
                <?php if (isAdmin()): ?>
                    <a href="<?= APP_URL ?>/pages/admin/dashboard.php" class="navbar-link <?= strpos($activePage, 'admin') !== false ? 'active' : '' ?>">
                        <i class="fa-solid fa-shield-halved"></i> Admin
                    </a>
                <?php endif; ?>
            <?php endif; ?>
        </nav>

        <div class="navbar-actions">
            <!-- Language Switcher -->
            <div class="lang-switcher">
                <a href="?lang=en" class="<?= ($_SESSION['lang'] ?? 'en') == 'en' ? 'active' : '' ?>">EN</a>
                <a href="?lang=fr" class="<?= ($_SESSION['lang'] ?? 'en') == 'fr' ? 'active' : '' ?>">FR</a>
            </div>

            <?php if ($currentUser): ?>
                <div class="user-menu" id="userMenu">
                    <button class="user-menu-toggle" id="userMenuToggle">
                        <span class="user-avatar"><?= strtoupper(substr($currentUser['username'], 0, 1)) ?></span>
                        <span class="user-name"><?= sanitize($currentUser['username']) ?></span>
                        <i class="fa-solid fa-chevron-down dropdown-arrow"></i>
                    </button>
                    <div class="user-dropdown" id="userDropdown">
                        <a href="<?= APP_URL ?>/pages/profile.php" class="dropdown-item"><i class="fa-solid fa-user"></i> <?= t('profile') ?></a>
                        <div class="dropdown-divider"></div>
                        <a href="<?= APP_URL ?>/includes/logout.php" class="dropdown-item logout"><i class="fa-solid fa-right-from-bracket"></i> <?= t('logout') ?></a>
                    </div>
                </div>
            <?php else: ?>
                <a href="<?= APP_URL ?>/pages/login.php" class="btn btn-ghost btn-sm"><?= t('login') ?></a>
                <a href="<?= APP_URL ?>/pages/register.php" class="btn btn-primary btn-sm"><?= t('register') ?></a>
            <?php endif; ?>
            <button class="navbar-toggle" id="navbarToggle"><span></span><span></span><span></span></button>
        </div>
    </div>
</header>
<div class="container flash-container"><?php renderFlash(); ?></div>
<main class="main-content">