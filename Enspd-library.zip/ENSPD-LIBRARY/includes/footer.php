<footer>

<img
src="<?= APP_URL ?>/assets/images/images.png"
height="60"
>

<h3>ENSPD-LIBRARY</h3>

<p>
Bibliothèque Numérique de l'École Nationale Supérieure Polytechnique de Douala
</p>

<p>
© 2025 ENSPD-LIBRARY
</p>

</footer>
