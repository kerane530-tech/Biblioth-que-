<?php
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

/**
 * Translation system with session persistence
 */
class I18n {
    private static $translations = [];
    private static $currentLang = 'en';
    
    public static function init() {
        // Load language from session, cookie, or default
        if (isset($_SESSION['lang']) && in_array($_SESSION['lang'], SUPPORTED_LANGUAGES)) {
            self::$currentLang = $_SESSION['lang'];
        } elseif (isset($_COOKIE['camexamhub_lang']) && in_array($_COOKIE['camexamhub_lang'], SUPPORTED_LANGUAGES)) {
            self::$currentLang = $_COOKIE['camexamhub_lang'];
            $_SESSION['lang'] = self::$currentLang;
        } else {
            // Detect browser language
            $browserLang = substr($_SERVER['HTTP_ACCEPT_LANGUAGE'] ?? 'en', 0, 2);
            self::$currentLang = in_array($browserLang, SUPPORTED_LANGUAGES) ? $browserLang : DEFAULT_LANGUAGE;
            $_SESSION['lang'] = self::$currentLang;
        }
        
        self::loadTranslations(self::$currentLang);
    }
    
    private static function loadTranslations($lang) {
        $file = __DIR__ . '/lang/' . $lang . '.php';
        if (file_exists($file)) {
            self::$translations = require $file;
        }
    }
    
    public static function t($key, $default = null) {
        return self::$translations[$key] ?? ($default ?? $key);
    }
    
    public static function setLanguage($lang) {
        if (in_array($lang, SUPPORTED_LANGUAGES)) {
            self::$currentLang = $lang;
            $_SESSION['lang'] = $lang;
            setcookie('camexamhub_lang', $lang, time() + (365 * 24 * 60 * 60), '/');
            self::loadTranslations($lang);
            return true;
        }
        return false;
    }
    
    public static function getCurrentLang() {
        return self::$currentLang;
    }
    
    public static function getAllTranslations() {
        return self::$translations;
    }
    
    public static function getAvailableLanguages() {
        return [
            'en' => 'English',
            'fr' => 'Français'
        ];
    }
}

// Helper function
function t($key, $default = null) {
    return I18n::t($key, $default);
}