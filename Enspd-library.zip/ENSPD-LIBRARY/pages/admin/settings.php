<?php
require_once __DIR__ . '/../../includes/bootstrap.php';
requireAdmin();
$pageTitle = t('admin_settings');
$activePage = 'admin_settings';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (isset($_POST['site_name'])) {
        dbQuery("UPDATE settings SET setting_value = ? WHERE setting_key = 'site_name'", [trim($_POST['site_name'])]);
    }
    if (isset($_FILES['site_logo']) && $_FILES['site_logo']['error'] === UPLOAD_ERR_OK) {
        $dir = APP_PATH . '/uploads/logo/';
        if (!is_dir($dir)) mkdir($dir, 0755, true);
        $upload = handleUpload($_FILES['site_logo'], $dir, ['png', 'jpg', 'jpeg', 'svg']);
        if ($upload['success']) {
            dbQuery("UPDATE settings SET setting_value = ? WHERE setting_key = 'logo_path'", ['uploads/logo/' . $upload['saved']]);
        }
    }
    setFlash('success', 'Settings saved successfully.');
    header('Location: ' . $_SERVER['REQUEST_URI']); exit;
}
require_once __DIR__ . '/../../includes/header.php';
?>
<div class="container admin-page">
    <h1><i class="fa-solid fa-gears"></i> <?= t('admin_settings') ?></h1>
    <form method="POST" enctype="multipart/form-data" class="admin-settings-form">
        <div class="form-group">
            <label>Site Name</label>
            <input type="text" name="site_name" class="form-control" value="<?= sanitize(getSetting('site_name')) ?>">
        </div>
        <div class="form-group">
            <label>Site Logo</label>
            <div class="current-logo">
                <img src="<?= getSiteLogo() ?>" alt="Current Logo" style="max-height: 60px;">
            </div>
            <input type="file" name="site_logo" class="form-control" accept="image/*">
        </div>
        <button type="submit" class="btn btn-primary"><i class="fa-solid fa-save"></i> Save Settings</button>
    </form>
</div>
<?php require_once __DIR__ . '/../../includes/footer.php'; ?>