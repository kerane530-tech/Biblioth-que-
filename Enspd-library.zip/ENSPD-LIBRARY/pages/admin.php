<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireAdmin();

$pageTitle = t('admin.title');
$activePage = 'admin';
$tab = $_GET['tab'] ?? 'dashboard';

// Handle actions
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['action'])) {
    if (!isset($_POST['csrf_token']) || !validateCSRFToken($_POST['csrf_token'])) {
        setFlash('error', 'Invalid request.');
    } else {
        $action = $_POST['action'];
        if ($action === 'update_paper_status') {
            $paperId = (int)$_POST['paper_id'];
            $status = $_POST['status'];
            dbQuery("UPDATE papers SET status = ? WHERE id = ?", [$status, $paperId]);
            setFlash('success', t('admin.paper_updated'));
        } elseif ($action === 'delete_paper') {
            $paperId = (int)$_POST['paper_id'];
            $paper = dbFetchOne("SELECT file_path FROM papers WHERE id = ?", [$paperId]);
            if ($paper && file_exists(UPLOAD_DIR . $paper['file_path'])) {
                unlink(UPLOAD_DIR . $paper['file_path']);
            }
            dbQuery("DELETE FROM papers WHERE id = ?", [$paperId]);
            setFlash('success', t('admin.paper_deleted'));
        } elseif ($action === 'delete_user') {
            $userId = (int)$_POST['user_id'];
            dbQuery("DELETE FROM users WHERE id = ? AND role != 'admin'", [$userId]);
            setFlash('success', t('admin.user_deleted'));
        } elseif ($action === 'update_settings') {
            foreach ($_POST['settings'] ?? [] as $key => $value) {
                updateSetting($key, $value);
            }
            setFlash('success', t('admin.settings_saved'));
        }
        header('Location: admin.php?tab=' . $tab);
        exit;
    }
}

// Stats
$totalUsers = dbFetchOne("SELECT COUNT(*) as count FROM users")['count'];
$totalPapers = dbFetchOne("SELECT COUNT(*) as count FROM papers")['count'];
$totalDownloads = dbFetchOne("SELECT COALESCE(SUM(download_count), 0) as count FROM papers")['count'];
$pendingPapers = dbFetchOne("SELECT COUNT(*) as count FROM papers WHERE status = 'pending'")['count'];

// Data for tabs
$recentPapers = dbFetchAll("SELECT p.*, s.name AS subject_name, u.username AS uploader_name FROM papers p JOIN subjects s ON p.subject_id = s.id JOIN users u ON p.uploaded_by = u.id ORDER BY p.created_at DESC LIMIT 20");$allUsers = dbFetchAll("SELECT id, username, email, full_name, role, is_active, created_at FROM users ORDER BY created_at DESC");
$settings = [];
$rows = dbFetchAll("SELECT key_name, key_value FROM app_settings");
foreach ($rows as $row) $settings[$row['key_name']] = $row['key_value'];

$csrfToken = generateCSRFToken();
require_once __DIR__ . '/../includes/header.php';
?>

<div class="container admin-page">
<div class="admin-layout">
    <aside class="admin-sidebar">
        <h3 style="margin-bottom:1.5rem;font-size:1.125rem;">⚙️ <?= t('admin.title') ?></h3>
        <ul class="admin-nav">
            <li><a href="?tab=dashboard" class="<?= $tab === 'dashboard' ? 'active' : '' ?>">📊 <?= t('admin.dashboard') ?></a></li>
            <li><a href="?tab=papers" class="<?= $tab === 'papers' ? 'active' : '' ?>">📄 <?= t('admin.papers') ?></a></li>
            <li><a href="?tab=users" class="<?= $tab === 'users' ? 'active' : '' ?>"> <?= t('admin.users') ?></a></li>
            <li><a href="?tab=settings" class="<?= $tab === 'settings' ? 'active' : '' ?>">⚙️ <?= t('admin.settings') ?></a></li>
        </ul>
    </aside>
    
    <div class="admin-content">
        <?php if ($tab === 'dashboard'): ?>
        <div class="admin-header"><h1><?= t('admin.dashboard') ?></h1></div>
        <div class="admin-stats">
            <div class="admin-stat-card"><span class="admin-stat-value"><?= number_format($totalUsers) ?></span><span class="admin-stat-label"><?= t('admin.total_users') ?></span></div>
            <div class="admin-stat-card blue"><span class="admin-stat-value"><?= number_format($totalPapers) ?></span><span class="admin-stat-label"><?= t('admin.total_papers') ?></span></div>
            <div class="admin-stat-card amber"><span class="admin-stat-value"><?= number_format($totalDownloads) ?></span><span class="admin-stat-label"><?= t('admin.total_downloads') ?></span></div>
            <div class="admin-stat-card red"><span class="admin-stat-value"><?= number_format($pendingPapers) ?></span><span class="admin-stat-label"><?= t('admin.pending_papers') ?></span></div>
        </div>
        <h3 style="margin-bottom:1rem;"><?= t('admin.recent_uploads') ?></h3>
        <table class="admin-table">
            <thead><tr><th>Title</th><th>Uploader</th><th>Subject</th><th>Status</th><th>Date</th></tr></thead>
            <tbody>
            <?php foreach (array_slice($recentPapers, 0, 10) as $p): ?>
            <tr>
                <td><a href="paper.php?id=<?= $p['id'] ?>"><?= sanitize(truncate($p['title'], 50)) ?></a></td>
                <td><?= sanitize($p['uploader_name']) ?></td>
                <td><?= sanitize($p['subject_name']) ?></td>
                <td><span class="status-badge status-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                <td><?= formatDate($p['created_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php elseif ($tab === 'papers'): ?>
        <div class="admin-header"><h1><?= t('admin.papers') ?></h1></div>
        <table class="admin-table">
            <thead><tr><th>ID</th><th>Title</th><th>Uploader</th><th>Status</th><th>Downloads</th><th>Actions</th></tr></thead>            <tbody>
            <?php foreach ($recentPapers as $p): ?>
            <tr>
                <td><?= $p['id'] ?></td>
                <td><a href="paper.php?id=<?= $p['id'] ?>"><?= sanitize(truncate($p['title'], 40)) ?></a></td>
                <td><?= sanitize($p['uploader_name']) ?></td>
                <td><span class="status-badge status-<?= $p['status'] ?>"><?= ucfirst($p['status']) ?></span></td>
                <td><?= $p['download_count'] ?></td>
                <td>
                    <div class="admin-actions">
                        <?php if ($p['status'] !== 'approved'): ?>
                        <form method="POST" style="display:inline;"><input type="hidden" name="csrf_token" value="<?= $csrfToken ?>"><input type="hidden" name="action" value="update_paper_status"><input type="hidden" name="paper_id" value="<?= $p['id'] ?>"><input type="hidden" name="status" value="approved"><button type="submit" class="btn btn-primary btn-sm"><?= t('admin.approve') ?></button></form>
                        <?php endif; ?>
                        <?php if ($p['status'] !== 'rejected'): ?>
                        <form method="POST" style="display:inline;"><input type="hidden" name="csrf_token" value="<?= $csrfToken ?>"><input type="hidden" name="action" value="update_paper_status"><input type="hidden" name="paper_id" value="<?= $p['id'] ?>"><input type="hidden" name="status" value="rejected"><button type="submit" class="btn btn-ghost btn-sm"><?= t('admin.reject') ?></button></form>
                        <?php endif; ?>
                        <form method="POST" style="display:inline;" onsubmit="return confirm('<?= t('admin.confirm_delete') ?>');"><input type="hidden" name="csrf_token" value="<?= $csrfToken ?>"><input type="hidden" name="action" value="delete_paper"><input type="hidden" name="paper_id" value="<?= $p['id'] ?>"><button type="submit" class="btn btn-danger btn-sm"><?= t('admin.delete') ?></button></form>
                    </div>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php elseif ($tab === 'users'): ?>
        <div class="admin-header"><h1><?= t('admin.users') ?></h1></div>
        <table class="admin-table">
            <thead><tr><th>ID</th><th>Username</th><th>Email</th><th>Role</th><th>Joined</th><th>Actions</th></tr></thead>
            <tbody>
            <?php foreach ($allUsers as $u): ?>
            <tr>
                <td><?= $u['id'] ?></td>
                <td><?= sanitize($u['username']) ?></td>
                <td><?= sanitize($u['email']) ?></td>
                <td><span class="status-badge <?= $u['role'] === 'admin' ? 'status-approved' : 'status-pending' ?>"><?= ucfirst($u['role']) ?></span></td>
                <td><?= formatDate($u['created_at']) ?></td>
                <td>
                    <?php if ($u['role'] !== 'admin'): ?>
                    <form method="POST" style="display:inline;" onsubmit="return confirm('<?= t('admin.confirm_delete') ?>');"><input type="hidden" name="csrf_token" value="<?= $csrfToken ?>"><input type="hidden" name="action" value="delete_user"><input type="hidden" name="user_id" value="<?= $u['id'] ?>"><button type="submit" class="btn btn-danger btn-sm"><?= t('admin.delete') ?></button></form>
                    <?php endif; ?>
                </td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
        
        <?php elseif ($tab === 'settings'): ?>
        <div class="admin-header"><h1><?= t('admin.settings') ?></h1></div>
        <form method="POST" class="settings-form">
            <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">            <input type="hidden" name="action" value="update_settings">
            <div class="form-group">
                <label>Max File Size (bytes)</label>
                <input type="number" name="settings[max_file_size]" class="form-control" value="<?= $settings['max_file_size'] ?? 52428800 ?>">
            </div>
            <div class="form-group">
                <label>Allowed Extensions (comma-separated)</label>
                <input type="text" name="settings[allowed_extensions]" class="form-control" value="<?= $settings['allowed_extensions'] ?? 'pdf,docx,txt,rtf' ?>">
            </div>
            <div class="form-group">
                <label>Papers Per Page</label>
                <input type="number" name="settings[papers_per_page]" class="form-control" value="<?= $settings['papers_per_page'] ?? 12 ?>">
            </div>
            <div class="form-group">
                <label>App Name</label>
                <input type="text" name="settings[app_name]" class="form-control" value="<?= $settings['app_name'] ?? 'CamExamHub' ?>">
            </div>
            <button type="submit" class="btn btn-primary"><?= t('admin.save') ?></button>
        </form>
        <?php endif; ?>
    </div>
</div>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>