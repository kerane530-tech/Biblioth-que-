<?php
require_once __DIR__ . '/../includes/bootstrap.php';
requireLogin();
$user = getCurrentUser();
if (!$user) { setFlash('error', 'User not found.'); header('Location: index.php'); exit; }

$pageTitle = t('profile.title');
$activePage = 'profile';

$myPapers = dbFetchAll("SELECT p.*, s.name AS subject_name, s.icon AS subject_icon FROM papers p JOIN subjects s ON p.subject_id = s.id WHERE p.uploaded_by = ? ORDER BY p.created_at DESC", [$user['id']]);
$myDownloads = dbFetchAll("SELECT d.*, p.title AS paper_title, p.file_type, s.name AS subject_name, s.icon AS subject_icon FROM downloads d JOIN papers p ON d.paper_id = p.id JOIN subjects s ON p.subject_id = s.id WHERE d.user_id = ? ORDER BY d.downloaded_at DESC LIMIT 20", [$user['id']]);

$totalUploads = count($myPapers);
$totalDownloads = count($myDownloads);
$totalViews = 0; $totalPaperDownloads = 0;
foreach ($myPapers as $p) { $totalViews += $p['view_count']; $totalPaperDownloads += $p['download_count']; }

require_once __DIR__ . '/../includes/header.php';
?>

<div class="container profile-page">
<div class="profile-header">
    <div class="profile-avatar"><?= strtoupper(substr($user['username'], 0, 2)) ?></div>
    <div class="profile-info">
        <h1><?= sanitize($user['full_name'] ?: $user['username']) ?></h1>
        <p>@<?= sanitize($user['username']) ?> • <?= sanitize($user['email']) ?></p>
        <p style="font-size:0.875rem;color:var(--text-tertiary);"><?= t('profile.member_since') ?> <?= formatDate($user['created_at'], 'F Y') ?>
        <?php if ($user['role'] === 'admin'): ?> • <span style="color:var(--accent);font-weight:600;"><?= t('profile.admin_badge') ?></span><?php endif; ?>
        </p>
    </div>
</div>

<div class="profile-stats">
    <div class="profile-stat-card"><span class="stat-number"><?= $totalUploads ?></span><span class="stat-label"><?= t('profile.papers_uploaded') ?></span></div>
    <div class="profile-stat-card"><span class="stat-number"><?= number_format($totalViews) ?></span><span class="stat-label"><?= t('profile.total_views') ?></span></div>
    <div class="profile-stat-card"><span class="stat-number"><?= number_format($totalPaperDownloads) ?></span><span class="stat-label"><?= t('profile.total_downloads') ?></span></div>
</div>

<div style="margin-bottom:3rem;">
    <h2 style="margin-bottom:1.5rem;">📤 <?= t('profile.my_papers') ?></h2>
    <?php if (!empty($myPapers)): ?>
    <div class="papers-grid">
        <?php foreach ($myPapers as $paper): ?>
        <div class="paper-card">
            <div class="paper-card-header">
                <span class="paper-subject-badge"><?= sanitize($paper['subject_icon'] ?? '📄') ?> <?= sanitize($paper['subject_name']) ?></span>
                <span class="paper-year"><?= sanitize($paper['publication_year'] ?? 'N/A') ?></span>
            </div>
            <h3><a href="paper.php?id=<?= $paper['id'] ?>"><?= sanitize($paper['title']) ?></a></h3>
            <p class="paper-abstract"><?= sanitize(truncate($paper['abstract'] ?? '', 150)) ?></p>
            <div class="paper-meta">
                <span>👁 <?= number_format($paper['view_count']) ?></span>
                <span>⬇ <?= number_format($paper['download_count']) ?></span>
                <span style="color:var(--gray-500);font-weight:500;"><?= sanitize(strtoupper($paper['status'])) ?></span>
            </div>
        </div>
        <?php endforeach; ?>
    </div>
    <?php else: ?>
    <div class="empty-state" style="padding:3rem;">
        <div class="empty-state-icon"></div>
        <h2><?= t('profile.no_papers') ?></h2>
        <p><?= t('profile.no_papers_desc') ?></p>
        <a href="upload.php" class="btn btn-primary"><?= t('profile.upload_first') ?></a>
    </div>
    <?php endif; ?>
</div>

<?php if (!empty($myDownloads)): ?>
<div>
    <h2 style="margin-bottom:1.5rem;"> <?= t('profile.download_history') ?></h2>
    <div style="background:var(--bg-card);border:1px solid var(--border-color);border-radius:var(--radius-xl);overflow:hidden;">
        <table style="width:100%;border-collapse:collapse;font-size:0.875rem;">
            <thead><tr style="background:var(--bg-tertiary);border-bottom:1px solid var(--border-color);">
                <th style="padding:0.75rem 1rem;text-align:left;font-weight:600;"><?= t('profile.paper') ?></th>
                <th style="padding:0.75rem 1rem;text-align:left;font-weight:600;"><?= t('profile.subject') ?></th>
                <th style="padding:0.75rem 1rem;text-align:left;font-weight:600;"><?= t('profile.format') ?></th>
                <th style="padding:0.75rem 1rem;text-align:left;font-weight:600;"><?= t('profile.date') ?></th>
            </tr></thead>
            <tbody>
            <?php foreach ($myDownloads as $dl): ?>
            <tr style="border-bottom:1px solid var(--border-light);">
                <td style="padding:0.75rem 1rem;"><a href="paper.php?id=<?= $dl['paper_id'] ?>" style="font-weight:500;"><?= sanitize(truncate($dl['paper_title'], 60)) ?></a></td>
                <td style="padding:0.75rem 1rem;"><?= sanitize($dl['subject_icon'] ?? '') ?> <?= sanitize($dl['subject_name']) ?></td>
                <td style="padding:0.75rem 1rem;text-transform:uppercase;"><?= sanitize($dl['file_type']) ?></td>
                <td style="padding:0.75rem 1rem;color:var(--text-tertiary);"><?= timeAgo($dl['downloaded_at']) ?></td>
            </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php endif; ?>
</div>

<?php require_once __DIR__ . '/../includes/footer.php'; ?>