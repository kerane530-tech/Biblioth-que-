# 📚 ENSPD-LIBRARY — Research Paper Discovery Platform

> A full-featured, production-ready web application for discovering, sharing, and downloading academic research papers. Built with pure PHP, MySQL, HTML, CSS, and vanilla JavaScript.

---

## 📋 Table of Contents

1. [Features](#-features)
2. [Technology Stack](#-technology-stack)
3. [Prerequisites](#-prerequisites)
4. [Installation Guide](#-installation-guide)
5. [Database Setup](#-database-setup)
6. [Project Structure](#-project-structure)
7. [Usage Guide](#-usage-guide)
8. [API Reference](#-api-reference)
9. [Security Features](#-security-features)
10. [Troubleshooting](#-troubleshooting)
11. [Development Notes](#-development-notes)
12. [License](#-license)

---

## ✨ Features

### For All Visitors (No Account Required)
- **Search Papers** — Full-text search across titles, authors, abstracts, and keywords
- **Browse by Subject** — Filter papers by academic discipline (10 subjects included)
- **Preview Papers** — View full paper details, abstract, metadata, and keywords inline
- **AJAX Search** — Instant search results on the landing page without page reload
- **Download Papers** — Download research papers as PDF/document files

### For Registered Users
- **Upload Papers** — Share research with drag-and-drop file upload
- **Paper Management** — View and manage your uploaded papers
- **Profile Dashboard** — Track uploads, views, and download statistics
- **Download History** — Review your past downloads

### For Administrators
- **Content Moderation** — Approve or reject paper submissions
- **User Management** — Manage user accounts and roles

### Technical Features
- 🔒 **Security** — CSRF protection, SQL injection prevention, XSS filtering, bcrypt passwords
- 📱 **Responsive** — Fully mobile-optimized with touch-friendly UI
- 🎨 **Modern UI** — Clean, professional design with CSS custom properties
- ⚡ **Fast** — Optimized queries, minimal dependencies
- 📝 **Well-Documented** — Comprehensive inline comments in all files

---

## 🛠️ Technology Stack

| Layer | Technology |
|-------|-----------|
| **Server** | PHP 7.4+ (procedural) |
| **Database** | MySQL 5.7+ / MariaDB 10.3+ |
| **Frontend** | HTML5, CSS3, Vanilla JavaScript |
| **Server Stack** | XAMPP (Apache + MySQL + PHP) |
| **Authentication** | PHP Sessions + bcrypt password hashing |
| **Database Access** | PDO with prepared statements |
| **No frameworks** | Pure PHP — no Laravel, Symfony, or CodeIgniter |

---

## 📦 Prerequisites

Before you begin, ensure you have:

1. **XAMPP** — Download from [apachefriends.org](https://www.apachefriends.org/)
   - Includes Apache, MySQL, and PHP
   - Works on Windows, macOS, and Linux

2. **A modern web browser** — Chrome, Firefox, Edge, or Safari

3. **No additional software required** — The application has zero external PHP dependencies

---

## 🚀 Installation Guide

### Step 1: Install XAMPP

1. Download XAMPP from https://www.apachefriends.org
2. Run the installer and follow the setup wizard
3. Choose the default installation directory: `C:\xampp` (Windows) or `/opt/lampp` (Linux)
4. Ensure Apache and MySQL components are selected

### Step 2: Start XAMPP Services

1. Open the **XAMPP Control Panel**
2. Click **Start** next to **Apache** (web server)
3. Click **Start** next to **MySQL** (database server)
4. Both services should show a green "Running" status

### Step 3: Copy Project Files

1. Locate your XAMPP `htdocs` directory:
   - **Windows:** `C:\xampp\htdocs\`
   - **macOS:** `/Applications/XAMPP/htdocs/`
   - **Linux:** `/opt/lampp/htdocs/`

2. Copy the **entire `php-app` folder** into `htdocs`:
   ```
   C:\xampp\htdocs\php-app\
   ```

3. The final path should be:
   ```
   C:\xampp\htdocs\php-app\index.php    ← Main entry point
   C:\xampp\htdocs\php-app\config\      ← Configuration files
   C:\xampp\htdocs\php-app\includes\    ← PHP includes
   C:\xampp\htdocs\php-app\pages\       ← Page templates
   C:\xampp\htdocs\php-app\api\         ← API endpoints
   C:\xampp\htdocs\php-app\assets\      ← CSS & JavaScript
   C:\xampp\htdocs\php-app\database\    ← SQL schema file
   C:\xampp\htdocs\php-app\uploads\     ← Uploaded files
   ```

### Step 4: Update Configuration (if needed)

Open `php-app/config/app.php` and verify the database settings match your XAMPP installation:

```php
// Default XAMPP settings — usually no changes needed
define('DB_HOST', 'localhost');
define('DB_PORT', '3306');
define('DB_USER', 'root');
define('DB_PASS', '');        // Empty by default on XAMPP
define('DB_NAME', 'research_papers');
```

Also update `APP_URL` if you renamed the folder:
```php
define('APP_URL', 'http://localhost/php-app');
```

---

## 🗄️ Database Setup

### Method 1: phpMyAdmin (Recommended)

1. Open your browser and navigate to: `http://localhost/phpmyadmin`
2. Click the **SQL** tab at the top
3. Click **Browse** and select the file: `php-app/database/schema.sql`
4. Click **Go** or **Import** to execute the SQL file
5. You should see a success message confirming the database was created

### Method 2: Command Line

Open a terminal/command prompt and run:

```bash
# Navigate to XAMPP MySQL bin directory
cd C:\xampp\mysql\bin     # Windows
# cd /opt/lampp/bin        # Linux

# Import the schema
mysql -u root -p < "C:\xampp\htdocs\php-app\database\schema.sql"
```

When prompted for a password, press **Enter** (empty by default).

### What Gets Created

The schema.sql file creates:

| Table | Description |
|-------|-------------|
| `research_papers` | The database |
| `users` | User accounts with authentication |
| `subjects` | 10 academic subject categories |
| `papers` | Research papers with full-text search |
| `downloads` | Download history tracking |
| `sessions` | Server-side session management |

Plus **seed data**: 2 demo users and 8 sample research papers.

---

## 📁 Project Structure

```
php-app/
├── index.php                  # Landing page (search + discovery)
├── .htaccess                  # Apache URL rewriting rules
│
├── config/
│   ├── app.php                # Application configuration constants
│   └── database.php           # Database connection & query helpers
│
├── includes/
│   ├── bootstrap.php          # Application initialization
│   ├── auth.php               # Authentication & session management
│   ├── functions.php          # Utility/helper functions
│   ├── header.php             # HTML header template (navbar)
│   ├── footer.php             # HTML footer template
│   └── logout.php             # Logout processor
│
├── pages/
│   ├── login.php              # User login
│   ├── register.php           # User registration
│   ├── browse.php             # Search results & paper listing
│   ├── paper.php              # Paper detail view
│   ├── upload.php             # Paper upload form
│   └── profile.php            # User profile & dashboard
│
├── api/
│   ├── search.php             # AJAX search endpoint (JSON)
│   └── download.php           # File download handler
│
├── assets/
│   ├── css/
│   │   └── style.css          # Complete stylesheet (~1200 lines)
│   ├── js/
│   │   └── app.js             # Client-side JavaScript
│   └── images/                # Static images (if any)
│
├── database/
│   └── schema.sql             # Complete MySQL database schema
│
└── uploads/
    ├── .htaccess              # Security: prevent directory browsing
    ├── papers/                # Uploaded research papers
    └── avatars/               # User profile avatars
```

---

## 📖 Usage Guide

### Accessing the Application

Open your browser and go to:
```
http://localhost/php-app/
```

### Creating an Account

1. Click **"Sign Up"** in the navigation bar
2. Fill in the registration form:
   - Username (3+ characters, letters/numbers/underscores)
   - Email address
   - Password (6+ characters)
   - Confirm password
3. Click **"Create Account"**
4. You'll be redirected to the login page

### Logging In

1. Click **"Log In"** in the navigation bar
2. Enter your email and password
3. Click **"Sign In"**

**Demo Account:**
- Email: `demo@example.com`
- Password: `password`

### Searching for Papers

1. On the homepage, type your search query in the search bar
2. Press **Enter** or click **Search**
3. Results appear instantly below the search bar (AJAX)
4. Click **"Preview"** to see full paper details
5. Click **"Download"** to save the paper to your device

**Search Tips:**
- Search by title: `machine learning`
- Search by author: `Smith`
- Search by keyword: `neural network`
- Search by subject: `physics`

### Browsing by Subject

1. Click a subject card on the homepage, OR
2. Go to **Browse** → use the sidebar to filter by subject
3. Apply additional filters: sort by date, downloads, views, or title

### Viewing Paper Details

1. Click on any paper title to open the detail page
2. View the full abstract, authors, publication info, and keywords
3. See download and view statistics
4. Click **"Download"** in the sidebar to save the paper

### Uploading Papers (Logged-in Users Only)

1. Click **"Upload"** in the navigation bar
2. Drag and drop your file, or click to browse
3. Fill in the paper metadata:
   - Title (required)
   - Subject category (required)
   - Authors
   - Publication year
   - Journal/conference name
   - DOI
   - Abstract
   - Keywords (comma-separated)
4. Click **"Upload Paper"**

**Supported file types:** PDF, DOC, DOCX, TXT, RTF
**Maximum file size:** 50MB

### Viewing Your Profile

1. Click your username/avatar in the navigation bar
2. Select **"My Profile"**
3. View your uploaded papers, statistics, and download history

---

## 🔌 API Reference

### Search API

```
GET /api/search.php?q=search_term
```

**Response (JSON):**
```json
{
    "success": true,
    "papers": [
        {
            "id": 1,
            "title": "Paper Title",
            "authors": "Author Names",
            "abstract": "Paper abstract...",
            "subject_name": "Computer Science",
            "subject_icon": "💻",
            "publication_year": 2024,
            "download_count": 42,
            "view_count": 150
        }
    ],
    "total": 1,
    "query": "search_term"
}
```

### Download API

```
GET /api/download.php?id=NNN
```

**Response:** File download with `Content-Disposition: attachment` header.

---

## 🔒 Security Features

| Feature | Implementation |
|---------|---------------|
| **SQL Injection Prevention** | PDO prepared statements with parameter binding |
| **XSS Prevention** | `htmlspecialchars()` output escaping on all user data |
| **CSRF Protection** | Token-based form validation with `hash_equals()` |
| **Password Security** | bcrypt hashing via `password_hash()` / `password_verify()` |
| **Session Security** | Session regeneration, timeout, and fixation prevention |
| **File Upload Validation** | Extension whitelist, MIME type checking, size limits |
| **Path Traversal Prevention** | `realpath()` verification for file downloads |
| **Directory Browsing** | Disabled via `.htaccess` `Options -Indexes` |
| **Direct Access Prevention** | `APP_RUNNING` constant gate on all includes |
| **Input Sanitization** | Filter functions for email, numeric, and text inputs |

---

## 🔧 Troubleshooting

### "Cannot connect to database"
- Ensure MySQL is running in XAMPP Control Panel
- Verify credentials in `config/app.php` match your XAMPP setup
- Default XAMPP: user=`root`, password=`` (empty)

### "Table doesn't exist"
- Import the database schema: `database/schema.sql`
- See [Database Setup](#-database-setup) section

### "Page not found" (404)
- Ensure Apache is running in XAMPP
- Check that the project is in the `htdocs` directory
- Verify the URL: `http://localhost/php-app/` (not `http://localhost/php-app`)

### "File upload failed"
- Check PHP upload limits in `php.ini`:
  ```
  upload_max_filesize = 50M
  post_max_size = 50M
  ```
- Ensure the `uploads/papers/` directory is writable:
  ```bash
  chmod 755 php-app/uploads/papers/
  ```

### "Session errors"
- Ensure PHP sessions are enabled in `php.ini`:
  ```
  session.auto_start = 0
  session.use_strict_mode = 1
  ```

### Blank page / PHP errors
- Check `config/app.php` — ensure `display_errors` is set to `1` for development
- Check Apache error logs: `C:\xampp\apache\logs\error.log`

### CSS/JavaScript not loading
- Verify the `APP_URL` in `config/app.php` matches your project path
- Check browser console for 404 errors on CSS/JS files
- Ensure `.htaccess` is allowed by Apache (`AllowOverride All`)

---

## 📝 Development Notes

### Code Organization
- **Separation of concerns:** Config, includes, pages, and API are in separate directories
- **Template pattern:** Header/footer templates are included in each page
- **Single entry point:** `bootstrap.php` initializes the entire application
- **Modular functions:** All helpers are in `functions.php` for easy maintenance

### Adding New Features
1. Create new pages in `pages/` directory
2. Add routes in `.htaccess` if needed
3. Use `require_once __DIR__ . '/../includes/bootstrap.php';` at the top
4. Use `getDB()` for database queries with prepared statements
5. Use `sanitize()` for HTML output escaping
6. Use `setFlash()` for post-redirect notifications

### Database Modifications
1. Edit `database/schema.sql` for schema changes
2. Use `dbQuery()` or `dbFetchOne()`/`dbFetchAll()` for queries
3. Always use parameterized queries — never interpolate user input

### Frontend Customization
- Edit `assets/css/style.css` for styling (CSS custom properties for theming)
- Edit `assets/js/app.js` for client-side behavior
- No build step required — pure CSS and vanilla JavaScript

---

## 📄 License

This project is provided as-is for educational and development purposes.
Feel free to modify and use it in your own projects.

---

**Built with ❤️ using PHP, MySQL, and vanilla web technologies.**
