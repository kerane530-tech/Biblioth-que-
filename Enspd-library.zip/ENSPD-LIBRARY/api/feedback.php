<?php
define('APP_RUNNING', true);
require_once __DIR__ . '/../config/app.php';
require_once __DIR__ . '/../config/database.php';
require_once __DIR__ . '/../includes/auth.php';
initSession();
require_once __DIR__ . '/../includes/functions.php';

header('Content-Type: application/json; charset=utf-8');

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    echo json_encode(['success' => false, 'message' => 'Method not allowed.']);
    exit;
}

$paperId = (int)($_POST['paper_id'] ?? 0);
$isHelpful = (bool)($_POST['is_helpful'] ?? false);
$userId = $_SESSION['user_id'] ?? null;

if ($paperId <= 0) {
    echo json_encode(['success' => false, 'message' => 'Invalid paper.']);
    exit;
}

$success = recordFeedback($paperId, $isHelpful, $userId);
echo json_encode(['success' => $success, 'message' => $success ? 'Feedback recorded.' : 'Already voted or error.']);