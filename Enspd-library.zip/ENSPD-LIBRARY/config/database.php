<?php
/**
 * ============================================================
 * Database Connection Handler
 * ============================================================
 * 
 * Provides a singleton PDO database connection with:
 * - Error handling via exceptions
 * - UTF-8 character set enforcement
 * - Prepared statement support
 * - Connection reuse across requests
 * 
 * Usage:
 *   $db = getDB();
 *   $stmt = $db->prepare("SELECT * FROM users WHERE id = ?");
 *   $stmt->execute([$userId]);
 * ============================================================
 */

// Prevent direct access
if (!defined('APP_RUNNING')) {
    http_response_code(403);
    exit('Direct access not permitted');
}

/**
 * Get the database connection (singleton pattern)
 * 
 * Creates a PDO connection to MySQL with proper error handling
 * and encoding settings. Reuses the connection on subsequent calls.
 * 
 * @return PDO Active database connection
 * @throws RuntimeException If connection fails
 */
function getDB(): PDO {
    /** @var PDO|null Static connection instance (persists across calls) */
    static $pdo = null;
    
    // Return existing connection if available
    if ($pdo !== null) {
        return $pdo;
    }
    
    try {
        // Build DSN (Data Source Name) for MySQL connection
        $dsn = sprintf(
            'mysql:host=%s;port=%s;dbname=%s;charset=utf8mb4',
            DB_HOST,
            DB_PORT,
            DB_NAME
        );
        
        // Create PDO connection with strict error handling
        $pdo = new PDO($dsn, DB_USER, DB_PASS, [
            // Throw exceptions on every error (not just fatal)
            PDO::ATTR_ERRMODE            => PDO::ERRMODE_EXCEPTION,
            // Return results as associative arrays by default
            PDO::ATTR_DEFAULT_FETCH_MODE => PDO::FETCH_ASSOC,
            // Disable emulated prepared statements (use real ones)
            PDO::ATTR_EMULATE_PREPARES   => false,
            // Set connection timeout to 10 seconds
            PDO::ATTR_TIMEOUT            => 10,
        ]);
        
        // Force UTF-8 encoding for consistent character handling
        $pdo->exec("SET NAMES utf8mb4 COLLATE utf8mb4_unicode_ci");
        
        return $pdo;
        
    } catch (PDOException $e) {
        // Log the actual error but show a generic message to users
        error_log('Database connection failed: ' . $e->getMessage());
        throw new RuntimeException(
            'Unable to connect to the database. Please ensure MySQL is running and configured correctly.'
        );
    }
}

/**
 * Execute a prepared statement with parameters
 * 
 * Convenience wrapper for common database operations that
 * handles parameter binding and execution in one call.
 * 
 * @param string $sql    SQL query with ? placeholders
 * @param array  $params Parameters to bind (default: empty array)
 * @return PDOStatement  Executed statement object
 */
function dbQuery(string $sql, array $params = []): PDOStatement {
    $db = getDB();
    $stmt = $db->prepare($sql);
    $stmt->execute($params);
    return $stmt;
}

/**
 * Fetch a single row from the database
 * 
 * @param string $sql    SQL query with ? placeholders
 * @param array  $params Parameters to bind
 * @return array|null    Single row as associative array, or null
 */
function dbFetchOne(string $sql, array $params = []): ?array {
    $result = dbQuery($sql, $params)->fetch();
    return $result ?: null;
}

/**
 * Fetch all matching rows from the database
 * 
 * @param string $sql    SQL query with ? placeholders
 * @param array  $params Parameters to bind
 * @return array         Array of rows (may be empty)
 */
function dbFetchAll(string $sql, array $params = []): array {
    return dbQuery($sql, $params)->fetchAll();
}

/**
 * Get the last inserted auto-increment ID
 * 
 * @return string Last insert ID
 */
function dbLastInsertId(): string {
    return getDB()->lastInsertId();
}
